/* delay */
#include "typ.h"
void delay_us(u32 dlyu);
void delay_ms(u32 dlym);
void delay_s(u32 dlys);
